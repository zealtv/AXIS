#ifndef _EXT_OMS_H_
#define _EXT_OMS_H_

// OMS is no longer supported

#endif /* _EXT_OMS_H_ */
